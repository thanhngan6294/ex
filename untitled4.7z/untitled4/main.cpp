#include "mainwindow.h"
#include <QApplication>
#include <QtGui>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.resize(400, 250);
    w.setWindowTitle("QTableWidget");
    w.show();

    return a.exec();
}
