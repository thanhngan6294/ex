#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QHBoxLayout>
#include <QTableWidget>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QHBoxLayout *hbox = new QHBoxLayout(this);

    QTableWidget *table = new QTableWidget(10, 10,this);

    hbox->addWidget(table);
    QHeaderView* header = table->horizontalHeader();
    header->setSectionResizeMode(QHeaderView::Stretch);
    //table->setGeometry(10, 10, 300, 100);
    //table->horizontalHeader()->hide();
    table->verticalHeader()->hide();
    table->setShowGrid(false);
    setCentralWidget(table);
}

MainWindow::~MainWindow()
{
    delete ui;
}
